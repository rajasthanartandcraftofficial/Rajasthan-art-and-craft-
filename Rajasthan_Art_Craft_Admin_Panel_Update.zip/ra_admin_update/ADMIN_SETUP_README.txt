RAJASTHAN ART AND CRAFT — ADMIN PANEL UPDATE

IMPORTANT
- This update is intended for the GitHub repository whose current files are index.html, style.css, app.js, admin.html.
- Before replacing anything, download a ZIP backup of the current GitHub repository (Code > Download ZIP).
- Upload/replace these four files at the ROOT of that repository: admin.html, admin.js, app.js, supabase-config.js.
- Do NOT upload the older styles.css from another ZIP over style.css. Do NOT delete the assets folder.

SUPABASE
- Uses the project's public URL and publishable key only. Never add a service_role or secret key.
- Expected table: public."Products" with columns id, name, description, price, category, image_url, gallery (jsonb), country_prices (jsonb).
- Expected public Storage bucket: product_images.
- Existing RLS policies must allow public SELECT on Products, admin-only INSERT/UPDATE/DELETE on Products, public SELECT on storage.objects for product_images, and admin-only INSERT/UPDATE/DELETE on that bucket.
- Auth user must have app_metadata.role = admin. After changing app_metadata, sign out and sign back in to refresh the session.

DEPLOY
1. GitHub repository root > Add file > Upload files.
2. Upload the four files above, allowing GitHub to replace the existing admin.html and app.js.
3. Commit changes to the same branch Vercel deploys (usually main).
4. Wait for Vercel deployment to finish.
5. Visit /admin.html and sign in with the Supabase Auth email/password.
6. Test adding one test product and verify the public site displays it before adding real products.

NOTE
- This code was written against the app.js structure pasted in chat. Test the deployment before relying on it for business operations. Product photos use the public product_images bucket URLs.
